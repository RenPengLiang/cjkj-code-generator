package com.cjkj.generator.dao;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cjkj.common.mapper.SuperMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * @author renpl
 * @Description:
 * @date 2019/7/3 17:19
 */
@Component
@Mapper
public interface CodeGeneratorDao extends SuperMapper {
    List<Map<String, Object>> queryList(Page<Map<String, Object>> page, @Param("p") Map<String, Object> map);

    int queryTotal(Map<String, Object> map);

    Map<String, String> queryTable(String tableName);

    List<Map<String, String>> queryColumns(String tableName);
}
