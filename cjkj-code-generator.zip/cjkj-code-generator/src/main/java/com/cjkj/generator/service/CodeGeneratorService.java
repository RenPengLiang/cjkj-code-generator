package com.cjkj.generator.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cjkj.common.model.PageData;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @author renpl
 * @Description:
 * @date 2019/7/3 17:36
 */
@Service
public interface CodeGeneratorService extends IService {
    PageData queryList(Map<String, Object> map);

    Map<String, String> queryTable(String tableName);

    List<Map<String, String>> queryColumns(String tableName);

    byte[] generatorCode(String[] tableNames);
}

